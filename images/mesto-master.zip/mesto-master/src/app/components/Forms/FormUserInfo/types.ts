export interface IProps {
  toggleUserInfoForm: () => void
}
