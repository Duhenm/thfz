export { FormAvatar } from 'app/components/Forms/FormAvatar'
export { FormUserInfo } from 'app/components/Forms/FormUserInfo'
export { FormPlace } from 'app/components/Forms/FormPlace'
