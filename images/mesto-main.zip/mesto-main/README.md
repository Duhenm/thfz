# Проектная работа №8, 4 курс, спринт 8

Проектная работа по курсу "JavaScript — непростые концепции". Данная работа выполнена по макету [Ссылка на макет в Figma](https://www.figma.com/file/kRVLKwYG3d1HGLvh7JFWRT/JavaScript.-Sprint-6). 

Проект доступен по [ссылке](https://alekseykurylev.github.io/mesto/).  

### В данном проекте используется:
* Верстка по методологии БЭМ
* Файловая структура Nested по БЭМ
* Flexbox CSS
* Grid CSS
* @media
* SVG
* JavaScript
* ООП
* Webpack