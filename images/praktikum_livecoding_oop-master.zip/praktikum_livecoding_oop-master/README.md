# Яндекс Практикум. Livecoding. Объектно-ориентированное программирование.

---

[Демо "Животные" на Github Pages](https://wain-pc.github.io/praktikum_livecoding_oop/animals.html)


[Демо "Список дел" на Github Pages](https://wain-pc.github.io/praktikum_livecoding_oop/todo.html)
