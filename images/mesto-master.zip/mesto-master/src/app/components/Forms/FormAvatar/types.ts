export interface IProps {
  toggleAvatarForm: () => void
}
