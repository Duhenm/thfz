export interface IProps {
  toggleAvatarForm?: () => void
  toggleUserInfoForm?: () => void
  togglePlaceForm?: () => void
}
