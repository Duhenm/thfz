import styled from 'styled-components'

export const Profile = styled.div`
  min-height: 300px;
  display: flex;
  align-items: center;
`
