import styled from 'styled-components'

export const Name = styled.h1`
  margin: 0;
  font-weight: normal;
  font-size: 54px;
  line-height: 56px;
`
