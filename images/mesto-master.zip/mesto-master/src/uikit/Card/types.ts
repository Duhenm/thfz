export interface IProps {
  name?: string
  likes: []
  link?: string
  owner?: string
  cardId?: string
}
