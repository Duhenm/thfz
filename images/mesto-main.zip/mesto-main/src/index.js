import './pages/index.css';
import './script/index.js';