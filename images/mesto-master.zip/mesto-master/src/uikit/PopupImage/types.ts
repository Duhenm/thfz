export interface IProps {
  src?: string
  alt?: string
  onClick?: () => void
}
