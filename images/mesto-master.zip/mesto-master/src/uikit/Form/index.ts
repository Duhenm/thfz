import styled from 'styled-components'

export const Form = styled.form`
  margin-top: 25px;
`
