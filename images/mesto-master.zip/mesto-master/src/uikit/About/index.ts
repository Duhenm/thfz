import styled from 'styled-components'

export const About = styled.p`
  margin: 20px 0 24px 0;
  font-size: 20px;
  line-height: 25px;
`
